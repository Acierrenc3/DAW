
package Juegos;

public interface IGames {
    public void inicio();
    
    public void desarrollo();
    
    public void fin();
}
