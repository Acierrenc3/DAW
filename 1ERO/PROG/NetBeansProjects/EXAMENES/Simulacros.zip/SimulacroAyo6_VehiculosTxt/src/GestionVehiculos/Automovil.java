
package GestionVehiculos;

public class Automovil extends Vehiculo{

    public Automovil(int añoFabricacion, long numeroVerificacion, String marca, String modelo) {
        super(añoFabricacion, numeroVerificacion, marca, modelo);
    }
    
    
    
}
